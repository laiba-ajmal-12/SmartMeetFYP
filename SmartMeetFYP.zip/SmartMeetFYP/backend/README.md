<<<<<<< HEAD
# Smart Meet – Online Meeting Platform with Engagement Tracking & Automated Reports

## Project Overview

Smart Meet is an intelligent online meeting platform that analyzes participant engagement using computer vision techniques such as gaze tracking and head pose estimation. It monitors attentiveness in real time during meetings and generates detailed post-meeting reports through a hybrid analysis approach.

The platform provides both individual and overall engagement scores, displayed through an interactive dashboard with visual analytics. This allows hosts to evaluate participation levels, identify engagement patterns, and make informed decisions to improve meeting effectiveness.

---

## Features

### Core Platform Features

* User authentication (Sign Up / Login)
* Role-based access (Host and Participants)
* Organization creation and management
* Participant management within organizations
* Meeting scheduling and listing
* Real-time meeting controls:

  * Join and leave meetings
  * Microphone mute/unmute
  * In-meeting chat
  * Screen sharing
* Cross-platform video communication
* Post-meeting engagement reports

### Engagement Tracking

* Real-time face-based attention detection
* Head pose estimation
* Gaze tracking
* Engagement scoring
* Automated report generation

---

## Tech Stack

### Frontend

* Next.js
* Tailwind CSS
=======
# Smart Meet – An Online Meeting Platform with Engagement Tracking and Automated Reports

# Project Description

Smart Meet is an online meeting platform that helps hosts understand how engaged participants are during virtual meetings.
It uses computer vision techniques such as head pose and gaze tracking to monitor attentiveness in real time. At the end of each session, the system generates automated reports showing individual participation and overall meeting productivity, allowing hosts to evaluate meeting effectiveness objectively.

## Features Implemented 

The following features are fully implemented in the current MVP:

## Core Platform Features

* User authentication (Sign Up / Login)
* Host role with ability to create organizations
* Host can add participants to organizations and meetings
* Meeting scheduling and listing for hosts
* Real-time meeting controls:
    * Join / Leave meeting
    * Microphone on/off
    * Audio mute/unmute
    * In-meeting chat
    * Screen sharing
 
## Technologies Used
>>>>>>> BackEnd

### Backend

* Node.js
* Express.js
<<<<<<< HEAD
* REST APIs
* GraphQL
=======
* REST APIs (for create/update/delete operations)
* GraphQL (for data retrieval)
>>>>>>> BackEnd

### Database

* PostgreSQL
* Prisma ORM

<<<<<<< HEAD
### Computer Vision Module

* Python
* OpenCV
* MediaPipe
* NumPy, Pandas

---

## Installation and Setup

### Prerequisites

* Node.js (v18 or higher)
* npm or yarn
* PostgreSQL
* Python (v3.9 or higher)
* Git

---

## Setup Instructions

### 1. Clone Repository

```bash
git clone <repository-url>
cd <project-root>
```

---

## Backend Setup
=======
## Setup Instructions

### Prerequisites

* Node.js (v18 or above recommended)
* npm
* PostgreSQL

### Backend Setup
>>>>>>> BackEnd

```termina(run these commands on terminal)
# First go to backend directory
npm install

# Generate Prisma client to develop the environment for prisma to run
npx prisma generate

# Run database migrations to apply all one by one
npx prisma migrate dev

# Start backend server
npm run dev
```
<<<<<<< HEAD
---

## Frontend Setup

```terminal(run these commands on terminal)
# Navigate to frontend directory
npm install

# Start frontend development server
npm run dev
```

---

## Environment Variables

Create `.env` files. Typical variables include:

* Database connection string
* Authentication secrets 
* Port configurations

---

## Running the Full System

1. Start PostgreSQL database
2. Start backend server
3. Start frontend server
4. Start computer vision module

Open the application in a browser using the configured frontend URL (for example: [http://localhost:3000](http://localhost:3000)).

---

## Usage Instructions

### For Hosts

1. Register or log in
2. Create an organization
3. Add participants
4. Schedule a meeting
5. Start the meeting and monitor engagement
6. View reports after the meeting

### For Participants

1. Join meetings using an invitation
2. Enable camera for engagement tracking
3. Participate using audio, video, and chat

---

## Reports and Analytics

After each meeting, the system provides:

* Individual engagement scores
* Attention tracking over time
* Participation summaries
* Overall meeting effectiveness

---

## Repository Structure and Branching

### Main Branches

* frontend – Frontend application
* backend – Backend services

### Supporting Branches
=======

### Environment Variables

A `.env` file is required for both frontend and backend. It typically includes:

. Database connection string
. Authentication secrets

## Repository Structure & Branching

### Main Branches

* `master` – Production-ready code
* `develop` – Stable development branch

### Feature & Supporting Branches
>>>>>>> BackEnd

* `feature/ui`
* `cv`
* `Smart-Meet-Server-only`
* `Backend`
* `server`
* `integration_b`

<<<<<<< HEAD
---

## Authentication

* JWT-based authentication
* Secure session handling
* Role-based access control

---

## Deployment Overview

* Configure environment variables
* Build frontend and backend
* Deploy services to hosting platforms
* Use a production database
* Enable HTTPS

---

## Notes

* All services (database, backend, frontend) should run simultaneously
* Camera access is required for engagement tracking
* Performance may vary depending on system hardware

---

## License

This project is developed for academic and educational purposes.

=======
## TODOs

The following items are planned for future sprints:

* Video mode during meetings (participants cannot currently see each other)
* Improvement and optimization of CV module
* Real-time warnings when participant attentiveness drops below a threshold
* Attendance calculation based on attention metrics
>>>>>>> BackEnd
